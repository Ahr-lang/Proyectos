﻿// métodos.cpp
// Implementación de métodos para leer el archivo de bitácora y ordenar las IPs por fan-out.
// Autores: Andrés Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192
// Fecha de entrega: Jueves 14 de noviembre

#include "header.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <limits>

using namespace std;

// Función para leer el archivo de bitácora y construir la lista de adyacencia
// Parámetros:
// nombreArchivo: nombre del archivo de bitácora
// adjList: mapa de adyacencia donde se almacenarán las conexiones
// Complejidad: O(n + m), donde n es la cantidad de IPs y m es la cantidad de conexiones
void leerIpsYConexiones(const string& nombreArchivo, map<string, vector<string>>& adjList) {
    ifstream archivo(nombreArchivo);
    if (!archivo) {
        cerr << "Error al abrir el archivo." << endl;
        return;
    }

    int n, m;
    archivo >> n >> m;
    archivo.ignore(); // Ignorar el salto de línea después de los enteros

    string ip;
    for (int i = 0; i < n; ++i) {
        getline(archivo, ip);
    }

    // Leer las incidencias y almacenar en la lista de adyacencia
    for (int i = 0; i < m; ++i) {
        string mes, dia, hora, ipOrigen, ipDestino;

        archivo >> mes >> dia >> hora >> ipOrigen >> ipDestino;

        string ipOrigenSinPuerto = ipOrigen.substr(0, ipOrigen.find(':'));
        string ipDestinoSinPuerto = ipDestino.substr(0, ipDestino.find(':'));

        adjList[ipOrigenSinPuerto].push_back(ipDestinoSinPuerto);

        archivo.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    archivo.close();
}

// Función de partición para quicksort, ordena por cantidad de conexiones de mayor a menor
// Complejidad promedio: O(n), donde n es la cantidad de elementos en el rango [low, high]
int partition(vector<fanOut>& arr, int low, int high) {
    int pivot = arr[high].count;
    int i = low - 1;

    for (int j = low; j <= high - 1; j++) {
        if (arr[j].count > pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return (i + 1);
}

// Función de ordenamiento rápido (quicksort) para ordenar el vector de fanOuts
// Parámetros:
// arr: vector de fanOuts a ordenar
// low: índice inicial
// high: índice final
// Complejidad promedio: O(n log n), donde n es la cantidad de elementos en el vector
// Complejidad peor caso: O(n^2), cuando el pivote es siempre el mayor o menor elemento
void quickSort(vector<fanOut>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

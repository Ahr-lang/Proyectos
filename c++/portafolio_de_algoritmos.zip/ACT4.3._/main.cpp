﻿// main.cpp
// Programa para analizar conexiones entre IPs a partir de un archivo de bitácora y ordenar por fan-out.
// Autores: Andrés Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192
// Fecha de entrega: Jueves 14 de noviembre

#include "header.h"
#include <iostream>

using namespace std;

int main() {
    // Mapa para almacenar las conexiones entre IPs
    // Complejidad del mapa (adjList): O(1) por inserción de clave única en el caso promedio
    map<string, vector<string>> adjList;

    // Leer el archivo de bitácora y llenar el mapa de conexiones
    // Complejidad: O(n + m), donde n es la cantidad de IPs y m es la cantidad de conexiones
    leerIpsYConexiones("bitacora.txt", adjList);

    vector<fanOut> fanouts;

    // Contar la cantidad de conexiones de cada nodo
    // Complejidad: O(p), donde p es la cantidad de IPs (o el tamaño de adjList)
    for (const auto& pair : adjList) {
        int count = pair.second.size();  // Obtener el tamaño de conexiones
        fanouts.push_back(fanOut(pair.first, count));
    }

    // Ordenar el vector de fanouts de mayor a menor
    // Complejidad promedio de quickSort: O(p log p), donde p es el tamaño de fanouts
    quickSort(fanouts, 0, fanouts.size() - 1);

    // Imprimir las 5 IPs con mayor cantidad de conexiones
    // Complejidad: O(1), ya que imprime un máximo de 5 elementos
    cout << "Top 5 IPs por cantidad de conexiones:" << endl;
    for (int i = 0; i < min(5, static_cast<int>(fanouts.size())); i++) {
        cout << fanouts[i].ip << " -> " << fanouts[i].count << endl;
    }

    return 0;
}

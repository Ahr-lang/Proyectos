﻿//header.h
//Declaraciones de funciones y estructura fanOut para manejo de conexiones entre IPs.
//Autores: Andrés Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192
//Fecha de entrega: Jueves 14 de noviembre

#ifndef HEADER_H
#define HEADER_H

#include <string>
#include <vector>
#include <map>

using namespace std;

// Estructura fanOut para almacenar cada IP y su conteo de conexiones
struct fanOut {
    string ip;
    int count;

    fanOut(string ip, int count) : ip(ip), count(count) {}
};

// Función para leer el archivo de bitácora y construir la lista de adyacencia
void leerIpsYConexiones(const string& nombreArchivo, map<string, vector<string>>& adjList);

// Función de búsqueda binaria para encontrar una IP en el vector fanOut
int busquedaBinaria(vector<fanOut>& fanouts, const string& ipBuscada);

// Función de ordenamiento rápido (quicksort) para ordenar el vector de fanOuts
void quickSort(vector<fanOut>& arr, int low, int high);

#endif // HEADER_H

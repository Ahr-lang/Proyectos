// Autores: Marcelo Salazar A01722192, Andr�s Huerta Robinson A00838626
// Fecha de creaci�n:19-09-2024

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <map>
#include <sstream>

using namespace std;

// Mapa para convertir el mes a un n�mero
map<string, int> mesToNum = {
    {"Jan", 1}, {"Feb", 2}, {"Mar", 3}, {"Apr", 4}, {"May", 5}, {"Jun", 6},
    {"Jul", 7}, {"Aug", 8}, {"Sep", 9}, {"Oct", 10}, {"Nov", 11}, {"Dec", 12}
};

// Funci�n para convertir una fila de la bit�cora en un n�mero comparable
long long convertirFecha(const vector<string>& fila) {
    int mes = mesToNum[fila[0]];
    int dia = stoi(fila[1]);

    // Convertir la hora a n�meros (formato HH:MM:SS)
    stringstream ss(fila[2]);
    string hora, minuto, segundo;
    getline(ss, hora, ':');
    getline(ss, minuto, ':');
    getline(ss, segundo);

    // Combinar todo en una secuencia de n�meros mes-d�a-hora-minuto-segundo
    long long fechaComparable = mes * 100000000 + dia * 1000000 + stoi(hora) * 10000 + stoi(minuto) * 100 + stoi(segundo);
    return fechaComparable;
}

// Funci�n para intercambiar dos filas en la matriz
void intercambio(vector<string>& fila1, vector<string>& fila2) {
    vector<string> aux = fila1;
    fila1 = fila2;
    fila2 = aux;
}

// Funci�n para realizar la partici�n del arreglo
int particion(vector<vector<string>>& matriz, int low, int high) {
    string pivot = matriz[high][0]; // Usar la primera columna como pivote (mes)
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (convertirFecha(matriz[j]) <= convertirFecha(matriz[high])) {
            i++;
            intercambio(matriz[i], matriz[j]);
        }
    }
    intercambio(matriz[i + 1], matriz[high]);
    return i + 1;
}

// Funci�n recursiva para realizar quicksort
void quicksort(vector<vector<string>>& matriz, int low, int high) {
    if (low < high) {
        int pi = particion(matriz, low, high);
        quicksort(matriz, low, pi - 1);
        quicksort(matriz, pi + 1, high);
    }
}

// Funci�n para generar el archivo con los registros en el rango de fechas
void generarRegistrosTXT(const vector<vector<string>>& matriz, long long fechaInicioComparable, long long fechaFinComparable) {
    ofstream file("Registros.txt");

    if (file.is_open()) {
        file << "Registros entre las fechas seleccionadas:\n\n";

        for (const auto& fila : matriz) {
            long long fechaRegistro = convertirFecha(fila);
            if (fechaRegistro >= fechaInicioComparable && fechaRegistro <= fechaFinComparable) {
                file << fila[0] << " " << fila[1] << " " << fila[2] << " " << fila[3] << " " << fila[4] << endl;
            }
        }

        file.close();
        cout << "Archivo Registros.txt generado exitosamente.\n";
    }
    else {
        cerr << "No se pudo generar el archivo Registros.txt.\n";
    }
}

int main() {
    ifstream file("bitacora.txt");
    if (!file) {
        cerr << "Error al abrir el archivo." << endl;
        return 1;
    }

    vector<vector<string>> matriz;
    string mes, dia, hora, ip, mensaje;

    // Leer el archivo y almacenar cada l�nea en la matriz
    while (file >> mes >> dia >> hora >> ip) {
        getline(file, mensaje); // Leer el resto de la l�nea como el mensaje completo
        vector<string> fila = { mes, dia, hora, ip, mensaje };
        matriz.push_back(fila);
    }

    file.close();

    // Ordenar la matriz por la fecha completa usando quicksort
    quicksort(matriz, 0, matriz.size() - 1);

    // Solicitar las fechas de inicio y fin de b�squeda al usuario
    string fechaInicioMes, fechaFinMes;
    int fechaInicioDia, fechaFinDia;
    string fechaInicioHora, fechaFinHora;

    cout << "Introduce la fecha de inicio (Mes D�a Hora): ";
    cin >> fechaInicioMes >> fechaInicioDia >> fechaInicioHora;

    cout << "Introduce la fecha de fin (Mes D�a Hora): ";
    cin >> fechaFinMes >> fechaFinDia >> fechaFinHora;

    // Convertir las fechas de inicio y fin a un valor comparable
    vector<string> fechaInicio = { fechaInicioMes, to_string(fechaInicioDia), fechaInicioHora };
    vector<string> fechaFin = { fechaFinMes, to_string(fechaFinDia), fechaFinHora };

    long long fechaInicioComparable = convertirFecha(fechaInicio);
    long long fechaFinComparable = convertirFecha(fechaFin);

    // Generar el archivo de registros entre las fechas seleccionadas
    generarRegistrosTXT(matriz, fechaInicioComparable, fechaFinComparable);


    return 0;
}

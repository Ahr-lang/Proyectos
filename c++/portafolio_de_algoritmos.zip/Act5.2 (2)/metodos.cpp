﻿#include "header.h"

// Convierte una IP en formato "xxx.xxx.xxx.xxx" a un número entero único
// Complejidad: O(n), donde n es el número de octetos 
int octToInt(const string& ip) {
    int result = 0;
    stringstream ss(ip);
    string segment;

    while (getline(ss, segment, '.')) { // Itera sobre los 4 octetos
        result = result * 256 + stoi(segment);
    }

    return result;
}

// Calcula el índice en la tabla hash usando sondeo cuadrático
// Complejidad: O(1) 
int hashFunction(int key, int i, int tableSize) {
    return (abs(key) + i * i) % tableSize;
}

// Inserta o actualiza una entrada en la tabla hash
// Complejidad: O(1) en promedio, O(n) en el peor caso (si es que existen colisiones)
void insertar(vector<HashEntry>& table, const string& mes, const string& dia, const string& hora, const string& ipOrigen, const string& ipDestino, bool imprimir) {
    int key = octToInt(ipOrigen);
    int i = 0;

    while (i < table.size()) { // Itera hasta encontrar una posición libre o la entrada correspondiente
        int index = hashFunction(key, i, table.size());

        if (!table[index].ocupado) { // Inserción directa
            if (imprimir) {
                cout << "Insertando en indice: " << index << endl;
            }

            table[index].ipOrigen = ipOrigen;
            table[index].ipsDestino.push_back(ipDestino);
            table[index].fechas.push_back(mes + " " + dia + " " + hora); // Guardar fecha completa
            table[index].incidenciasTotales++;
            table[index].ocupado = true;
            return;
        }
        else if (table[index].ipOrigen == ipOrigen) { // Actualización
            if (imprimir) {
                cout << "Actualizando en indice: " << index << endl;
            }

            table[index].ipsDestino.push_back(ipDestino);
            table[index].fechas.push_back(mes + " " + dia + " " + hora); // Agregar nueva fecha
            table[index].incidenciasTotales++;
            return;
        }

        i++;
    }

    cerr << "Error: Tabla hash llena. No se pudo insertar " << ipOrigen << endl;
    exit(EXIT_FAILURE);
}

// Lee datos de la bitácora desde un archivo
// Complejidad: O(n + m), donde n es el número de IPs únicas y m el número de incidencias
void leerBitacora(const string& filename, vector<HashEntry>& table) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error: No se pudo abrir el archivo " << filename << endl;
        exit(EXIT_FAILURE);
    }

    int n, m;
    if (!(file >> n >> m)) { // Lectura inicial
        cerr << "Error: Formato inválido en la primera linea del archivo." << endl;
        exit(EXIT_FAILURE);
    }

    file.ignore(numeric_limits<streamsize>::max(), '\n');

    string mes, dia, hora, ipOrigen, ipDestino, razon;
    for (int i = 0; i < m; ++i) { // Itera sobre las incidencias
        if (!(file >> mes >> dia >> hora >> ipOrigen >> ipDestino)) {
            cerr << "Error: Formato inválido en las incidencias." << endl;
            exit(EXIT_FAILURE);
        }

        getline(file, razon); // Leer la razón completa
        ipOrigen = ipOrigen.substr(0, ipOrigen.find(':'));
        ipDestino = ipDestino.substr(0, ipDestino.find(':'));

        insertar(table, mes, dia, hora, ipOrigen, ipDestino, false); // Inserta en la tabla hash
    }

    file.close();
}

// Muestra la información de una IP de origen
// Complejidad: O(1) en promedio, O(n) en el peor de los casos
void mostrarInformacion(const string& ip, const vector<HashEntry>& table) {
    int key = octToInt(ip);
    int i = 0;

    while (i < table.size()) {
        int index = hashFunction(key, i, table.size());

        if (table[index].ocupado && table[index].ipOrigen == ip) {
            cout << "IP de origen: " << ip << endl;
            cout << "Incidencias totales: " << table[index].incidenciasTotales << endl;

            cout << "Detalles de las incidencias:" << endl;
            for (size_t j = 0; j < table[index].ipsDestino.size(); ++j) {
                cout << "- Fecha: " << table[index].fechas[j]
                    << ", IP de destino: " << table[index].ipsDestino[j] << endl;
            }
            return;
        }

        i++;
    }

    cerr << "Error: IP no encontrada en la tabla hash." << endl;
}

// Cuenta las IPs únicas de destino para una IP de origen
// Complejidad: O(n), donde n es el número de IPs de destino
int contarIpsUnicas(const string& ip, const vector<HashEntry>& table) {
    int key = octToInt(ip);
    int i = 0;
    vector<string> ipsUnicas;

    while (i < table.size()) {
        int index = hashFunction(key, i, table.size());

        if (table[index].ocupado && table[index].ipOrigen == ip) {
            // Insertar cada IP de destino en el vector solo si no está ya presente
            for (const string& ipDestino : table[index].ipsDestino) {
                bool existe = false;
                for (const string& ipGuardada : ipsUnicas) {
                    if (ipGuardada == ipDestino) {
                        existe = true;  // La IP ya está en el vector, no la añadimos
                        break;
                    }
                }
                if (!existe) {
                    ipsUnicas.push_back(ipDestino);  // Añadimos solo si es única
                }
            }

            // Mostrar el número de IPs únicas
            cout << "Numero de IPs de destino unicas para la IP de origen " << ip << ": " << ipsUnicas.size() << endl;
            cout << "IPs de destino unicas para la IP de origen " << ip << ":\n";

            // Mostrar las IPs únicas
            for (const string& ip : ipsUnicas) {
                cout << "- " << ip << endl;
            }

            // Retornar el número de IPs únicas
            return ipsUnicas.size();
        }

        i++;
    }

    cerr << "Error: IP no encontrada en la tabla hash." << endl;
    return 0; // Si no encontramos la IP de origen
}
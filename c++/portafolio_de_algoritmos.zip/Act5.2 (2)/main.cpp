// Descripci�n: Programa que implementa una tabla hash para procesar datos de una bit�cora.
// Autores: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192
// Fecha de entrega: Jueves, 21 de Noviembre del 2024

#include "header.h"
#include <iostream>
#include <ctime>

using namespace std;

int main() {
    // Inicializa la tabla hash con un tama�o inicial de 100,000
    vector<HashEntry> hashTable(100000); 

    // Leer los datos de la bit�cora desde un archivo
    leerBitacora("bitacora.txt", hashTable); // Complejidad O(n)

    // Solicitar al usuario las IPs de origen y destino para insertar
    string ipOrigen, ipDestino;
    cout << "Introduce la IP de origen para insertar: ";
    cin >> ipOrigen; 
    cout << "Introduce la IP de destino para insertar: ";
    cin >> ipDestino; 

    // Generar autom�ticamente la fecha y hora actuales
    time_t now = time(0);
    tm localTime;
    localtime_s(&localTime, &now); 

    string mes = to_string(localTime.tm_mon + 1); 
    string dia = to_string(localTime.tm_mday);   
    string hora = to_string(localTime.tm_hour) + ":" +
        to_string(localTime.tm_min) + ":" +
        to_string(localTime.tm_sec);   

    // Insertar la nueva entrada en la tabla hash
    insertar(hashTable, mes, dia, hora, ipOrigen, ipDestino, true); 

    // Mostrar la informaci�n de la IP de origen ingresada
    cout << "\nMostrando informaci�n de la IP de origen: " << ipOrigen << endl;
    mostrarInformacion(ipOrigen, hashTable); // Complejidad O(1) en promedio

    // Contar las IPs �nicas asociadas con la IP de origen
    int numIpsUnicas = contarIpsUnicas(ipOrigen, hashTable); // Complejidad O(n)
    cout << "N�mero de IPs de destino �nicas para la IP de origen " << ipOrigen << ": " << numIpsUnicas << endl;

    return 0;
}
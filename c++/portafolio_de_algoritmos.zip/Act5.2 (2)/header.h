﻿#ifndef HEADER_H
#define HEADER_H

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <limits>
#include <cmath>

using namespace std;

// Estructura para representar una entrada en la tabla hash
struct HashEntry {
    string ipOrigen;                // IP de origen
    vector<string> ipsDestino;      // Lista de IPs de destino
    vector<string> fechas;          // Fechas asociadas a las conexiones
    int incidenciasTotales;         // Número total de incidencias
    bool ocupado;                   // Bandera para verificar si la entrada está ocupada

    HashEntry() {
        incidenciasTotales = 0;
        ocupado = false;
    }
};

// Prototipos de funciones
int octToInt(const string& ip);
int hashFunction(int key, int i, int tableSize);
void insertar(vector<HashEntry>& table, const string& mes, const string& dia, const string& hora, const string& ipOrigen, const string& ipDestino, bool imprimir);
void leerBitacora(const string& filename, vector<HashEntry>& table);
void mostrarInformacion(const string& ip, const vector<HashEntry>& table);
int contarIpsUnicas(const string& ip, const vector<HashEntry>& table);

#endif

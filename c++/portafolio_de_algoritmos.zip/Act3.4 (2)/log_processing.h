// logProcessing.h
// Descripci�n: Funciones para el procesamiento de registros de bit�cora
// Autores: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192 
// Fecha de entrega: Jueves, Octubre 31 del 2024

#pragma once
#include "node.h"
#include "bstNode.h"
#include <string>
#include <vector>

struct IpLog {
    std::string ipAddress; // Direcci�n IP
    int count; // N�mero de veces que se repite
};

extern std::vector<IpLog> data; // Almacena IPs y su conteo

void readTxt(LinkedList& logList); // Lee archivo y almacena en lista enlazada
std::vector<LogEntryExt> linkedListToVector(LinkedList& logList); // Convierte lista a vector
void countIPs(const std::vector<std::string>& ipAddresses, BstTree& ipTree); // Cuenta ocurrencias en BST
std::string intToOct(uint32_t ip); // Convierte IP de entero a cadena
int binaryQuery(const std::vector<LogEntryExt>& arr, int left, int right, uint32_t targetIp); // B�squeda binaria

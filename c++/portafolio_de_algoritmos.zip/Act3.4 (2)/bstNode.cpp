// bstNode.cpp
// Descripci�n: Implementaci�n de los m�todos del �rbol binario de b�squeda (BST) para IPs
// Autores: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192 
// Fecha de entrega: Jueves, Octubre 31 del 2024

#include "bstNode.h"
#include <iostream>
#include <utility>

BstNode::BstNode(int count, const std::string& ipAddress)
    : count(count), ipAddress(ipAddress), left(nullptr), right(nullptr) {}

BstTree::BstTree() : root(nullptr) {}

BstNode* BstTree::addNode(BstNode* addRoot, int count, const std::string& ipAddress) {
    if (addRoot == nullptr) {
        return new BstNode(count, ipAddress);
    }

    if (count > addRoot->count) {
        addRoot->right = addNode(addRoot->right, count, ipAddress);
    }
    else if (count < addRoot->count) {
        addRoot->left = addNode(addRoot->left, count, ipAddress);
    }
    return addRoot;
}

void BstTree::addNode(int count, const std::string& ipAddress) {
    root = addNode(root, count, ipAddress);
}

void BstTree::findTopIPs(BstNode* root, std::vector<BstNode*>& topIPs, int& minCount, int maxEntries) {
    if (!root) return;

    findTopIPs(root->right, topIPs, minCount, maxEntries);

    if (topIPs.size() < maxEntries || root->count > minCount) {
        if (topIPs.size() == maxEntries) {
            topIPs.pop_back();
        }
        topIPs.push_back(root);
        if (topIPs.size() == maxEntries) {
            minCount = topIPs.back()->count;
        }
    }

    findTopIPs(root->left, topIPs, minCount, maxEntries);
}

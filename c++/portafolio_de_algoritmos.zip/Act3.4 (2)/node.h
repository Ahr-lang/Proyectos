// node.h
// Descripci�n: Estructuras para nodos de lista y registros de bit�cora
// Autores: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192 
// Fecha de entrega: Jueves, Octubre 31 del 2024

#pragma once
#include <string>
#include <cstdint>

struct LogEntryExt {
    std::string ipAddressStr;
    uint32_t ipAddressUint;
    std::string log;
    int count = 0;
};

class Node {
public:
    LogEntryExt data;
    Node* next;
    Node* prev;

    Node();
    Node(const LogEntryExt& data);
};

class LinkedList {
public:
    Node* head;
    Node* tail;

    LinkedList();
    void insertAtBeginning(const LogEntryExt& data);
    void insertAtEnd(const LogEntryExt& data);
    void displayForward() const;
    void quickSort(Node* start, Node* end);
    Node* partition(Node* low, Node* high);
    void sort();
};

uint32_t ipToUint32(const std::string& ip);
int compareIPs(uint32_t ip1, uint32_t ip2);

// main.cpp
// Descripci�n: Programa para procesar registros de bit�cora, extraer direcciones IP, y contar ocurrencias.
// Autores: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192 
// Fecha de entrega: Jueves, Octubre 31 del 2024

#include "log_Processing.h"
#include <iostream>
#include <vector>

int main() {
    LinkedList logList;

    // Leer entradas de bit�cora desde bitacora.txt y almacenarlas en la lista enlazada
    readTxt(logList);

    // Convertir lista enlazada a un vector de objetos LogEntryExt
    std::vector<LogEntryExt> logEntries = linkedListToVector(logList);

    // Extraer direcciones IP de las entradas de log
    std::vector<std::string> ipAddresses;
    for (const auto& entry : logEntries) {
        ipAddresses.push_back(entry.ipAddressStr);
    }

    // Crear �rbol binario de b�squeda y contar ocurrencias de cada IP
    BstTree ipTree;
    countIPs(ipAddresses, ipTree);

    // Encontrar las 5 IPs con m�s accesos
    std::vector<BstNode*> topIPs;
    int minCount = 0;
    ipTree.findTopIPs(ipTree.root, topIPs, minCount, 5);

    // Imprimir las 5 IPs principales y sus conteos
    std::cout << "Top 5 IPs con m�s accesos:" << std::endl;
    for (const auto& node : topIPs) {
        std::cout << "IP: " << node->ipAddress << " | Count: " << node->count << std::endl;
    }

    return 0;
}

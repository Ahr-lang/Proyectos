// node.cpp
// Descripci�n: Implementaci�n de las clases y m�todos de la lista enlazada y nodos de bit�cora
// Autores: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192 
// Fecha de entrega: Jueves, Octubre 31 del 2024

#include "node.h"
#include <sstream>
#include <iostream>

Node::Node() : next(nullptr), prev(nullptr) {}

Node::Node(const LogEntryExt& data) : data(data), next(nullptr), prev(nullptr) {}

LinkedList::LinkedList() : head(nullptr), tail(nullptr) {}

void LinkedList::insertAtBeginning(const LogEntryExt& data) {
    Node* newNode = new Node(data);
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    }
    else {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
}

void LinkedList::insertAtEnd(const LogEntryExt& data) {
    Node* newNode = new Node(data);
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
}

void LinkedList::displayForward() const {
    Node* current = head;
    while (current != nullptr) {
        std::cout << "IP: " << current->data.ipAddressUint << " | Log: " << current->data.log << std::endl;
        current = current->next;
    }
}

Node* LinkedList::partition(Node* low, Node* high) {
    uint32_t pivot = high->data.ipAddressUint;
    Node* i = low->prev;

    for (Node* j = low; j != high; j = j->next) {
        if (j->data.ipAddressUint <= pivot) {
            i = (i == nullptr) ? low : i->next;
            std::swap(i->data, j->data);
        }
    }
    i = (i == nullptr) ? low : i->next;
    std::swap(i->data, high->data);
    return i;
}

void LinkedList::quickSort(Node* low, Node* high) {
    if (low == nullptr || high == nullptr || low == high || low == high->next) {
        return;
    }

    Node* pivotNode = partition(low, high);

    if (pivotNode->prev != nullptr && low != pivotNode->prev) {
        quickSort(low, pivotNode->prev);
    }

    if (pivotNode->next != nullptr && high != pivotNode->next) {
        quickSort(pivotNode->next, high);
    }
}

void LinkedList::sort() {
    if (head == nullptr || tail == nullptr) {
        return;
    }
    quickSort(head, tail);
}

uint32_t ipToUint32(const std::string& ip) {
    uint32_t result = 0;
    std::stringstream ss(ip);
    std::string octet;
    int shift = 24;

    while (getline(ss, octet, '.')) {
        result |= (std::stoi(octet) << shift);
        shift -= 8;
    }

    return result;
}

int compareIPs(uint32_t ip1, uint32_t ip2) {
    if (ip1 == ip2) return 0;
    return (ip1 < ip2) ? -1 : 1;
}

// bstNode.h
// Descripci�n: Definici�n de nodos y �rbol binario para conteo de direcciones IP
// Autores: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192 
// Fecha de entrega: Jueves, Octubre 31 del 2024

#pragma once
#include <vector>
#include <string>

class BstNode {
public:
    int count; // N�mero de accesos
    std::string ipAddress; // Direcci�n IP
    BstNode* left;
    BstNode* right;

    BstNode(int count, const std::string& ipAddress); // Constructor con contador e IP
};

class BstTree {
public:
    BstNode* root;

    BstTree();
    BstNode* addNode(BstNode* addRoot, int count, const std::string& ipAddress);
    void addNode(int count, const std::string& ipAddress);
    void findTopIPs(BstNode* root, std::vector<BstNode*>& topIPs, int& minCount, int maxEntries);
};

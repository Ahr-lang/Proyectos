// logProcessing.cpp
// Descripci�n: Implementaci�n de funciones para el procesamiento de registros de bit�cora
// Autores: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192 
// Fecha de entrega: Jueves, Octubre 31 del 2024

#include "log_Processing.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <unordered_map>

std::vector<IpLog> data;

void readTxt(LinkedList& logList) {
    std::ifstream file("bitacora.txt");
    if (!file) {
        std::cerr << "No se pudo abrir el archivo bitacora.txt" << std::endl;
        return;
    }

    std::string line;
    int lineCount = 0;

    while (getline(file, line)) {
        LogEntryExt entry;
        std::stringstream ss(line);
        std::string token;
        int i = 0;

        while (getline(ss, token, ' ')) {
            if (i == 3) {
                size_t colonPos = token.find(':');
                entry.ipAddressStr = (colonPos != std::string::npos) ? token.substr(0, colonPos) : token;
                entry.ipAddressUint = ipToUint32(entry.ipAddressStr);
                entry.count = 1;
                break;
            }
            i++;
        }

        logList.insertAtEnd(entry);
        lineCount++;
    }

    std::cout << "Se leyeron " << lineCount << " direcciones IP del archivo." << std::endl;
    file.close();
}

void countIPs(const std::vector<std::string>& ipAddresses, BstTree& ipTree) {
    std::unordered_map<std::string, int> ipCounts;

    for (const auto& ip : ipAddresses) {
        ipCounts[ip]++;
    }

    for (auto it = ipCounts.begin(); it != ipCounts.end(); ++it) {
        ipTree.addNode(it->second, it->first);
    }
}

std::string intToOct(uint32_t ip) {
    return std::to_string((ip >> 24) & 0xFF) + "." +
        std::to_string((ip >> 16) & 0xFF) + "." +
        std::to_string((ip >> 8) & 0xFF) + "." +
        std::to_string(ip & 0xFF);
}

int binaryQuery(const std::vector<LogEntryExt>& arr, int left, int right, uint32_t targetIp) {
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid].ipAddressUint == targetIp) {
            return mid;
        }
        if (arr[mid].ipAddressUint < targetIp) {
            left = mid + 1;
        }
        else {
            right = mid - 1;
        }
    }
    return -1;
}

std::vector<LogEntryExt> linkedListToVector(LinkedList& logList) {
    std::vector<LogEntryExt> logEntries;
    Node* current = logList.head;

    while (current != nullptr) {
        logEntries.push_back(current->data);
        current = current->next;
    }

    std::cout << "Lista enlazada convertida a vector con " << logEntries.size() << " entradas." << std::endl;
    return logEntries;
}

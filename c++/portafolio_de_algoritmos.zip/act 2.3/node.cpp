 #include "node.h"
#include <sstream>
#include <iostream>
#include <utility>
#include <vector>

using namespace std;

// Constructor por defecto de Node
Node::Node() {
    data.ipAddress = 0;
    data.log = "";
    next = nullptr;
    prev = nullptr;
}

// Constructor con LogEntry
Node::Node(LogEntry data) {
    this->data = data;
    this->next = nullptr;
    this->prev = nullptr;
}

// Constructor de LinkedList
LinkedList::LinkedList() {
    this->head = nullptr;
    this->tail = nullptr;
}

// Insertar al inicio de la lista
void LinkedList::insertAtBeginning(Node*& head, Node*& tail, LogEntry data) {
    Node* newNode = new Node(data);
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
        return;
    }
    newNode->next = head;
    head->prev = newNode;
    head = newNode;
}

// Insertar al final de la lista
void LinkedList::insertAtEnd(Node*& head, Node*& tail, LogEntry data) {
    Node* newNode = new Node(data);
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
        return;
    }
    tail->next = newNode;
    newNode->prev = tail;
    tail = newNode;
}

// Mostrar la lista desde el inicio hasta el final
void LinkedList::displayForward() {
    Node* current = head;
    while (current != nullptr) {
        cout << "IP: " << current->data.ipAddress << " | Log: " << current->data.log << endl;
        current = current->next;
    }
}

// Funci�n de partici�n para quicksort
Node* LinkedList::partition(Node* low, Node* high) {
    uint32_t pivot = high->data.ipAddress;
    Node* i = low->prev;

    for (Node* j = low; j != high; j = j->next) {
        if (j->data.ipAddress <= pivot) {
            i = (i == nullptr) ? low : i->next;
            swap(i->data, j->data);
        }
    }
    i = (i == nullptr) ? low : i->next;
    swap(i->data, high->data);
    return i;
}

// Funci�n recursiva de QuickSort
void LinkedList::quickSort(Node* low, Node* high) {
    if (low == nullptr || high == nullptr || low == high || low == high->next) {
        return;
    }

    Node* pivotNode = partition(low, high);

    if (pivotNode->prev != nullptr && low != pivotNode->prev) {
        quickSort(low, pivotNode->prev);
    }

    if (pivotNode->next != nullptr && high != pivotNode->next) {
        quickSort(pivotNode->next, high);
    }
}

// Iniciar el proceso de ordenamiento
void LinkedList::sort() {
    if (head == nullptr || tail == nullptr) {
        return;
    }
    quickSort(head, tail);
}

// Convertir una direcci�n IP en string a un entero de 32 bits
uint32_t octToInt(string oct) {
    uint32_t octet = 0;
    stringstream ss(oct);
    string token;

    int i = 0;
    while (getline(ss, token, '.')) {
        switch (i) {
        case 0: octet = (stoi(token) << 24); break;
        case 1: octet += (stoi(token) << 16); break;
        case 2: octet += (stoi(token) << 8); break;
        case 3: octet += stoi(token); break;
        }
        i++;
    }
    return octet;
}

// Comparar dos direcciones IP en formato entero
int compareOctToInt(uint32_t ip1, uint32_t ip2) {
    if (ip1 == ip2) return 0;
    else if (ip1 < ip2) return -1;
    else return 1;
}

// Funci�n de b�squeda binaria
int binaryQuery(vector<LogEntry>& arr, int izquierda, int derecha, uint32_t targetIP) {
    while (izquierda <= derecha) {
        int mid = izquierda + (derecha - izquierda) / 2;
        if (arr[mid].ipAddress == targetIP) {
            return mid;
        }
        if (arr[mid].ipAddress < targetIP) {
            izquierda = mid + 1;
        }
        else {
            derecha = mid - 1;
        }
    }
    return -1; // No encontrado
}
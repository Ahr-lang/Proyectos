 /*
 * Programa: Procesamiento de Bit�cora
 * Autor: Andr�s Huerta A00838626, Eugenio Diaz A01722851, Marcelo Salazar A01722192
 * Fecha de creaci�n/modificaci�n: [Fecha]
 * Descripci�n: El programa lee un archivo de bit�cora, ordena los registros por direcci�n IP
 *              y realiza b�squedas en un rango de direcciones IP especificado por el usuario.
 *              Los resultados se almacenan en un archivo de salida.
 */

#include "node.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>

using namespace std;

/*
 * Funci�n: readTxt
 * Descripci�n: Lee el archivo 'bitacora.txt' y procesa cada l�nea para almacenar los registros
 *              en una lista doblemente enlazada.
 * Par�metros:
 *     - logList: Referencia a la lista doblemente enlazada donde se almacenar�n los registros.
 * Valor de retorno: Ninguno.
 */
void readTxt(LinkedList& logList) {
    ifstream file("bitacora.txt");

    if (!file) {
        cerr << "Unable to open file bitacora.txt" << endl;
        return;
    }

    string line;
    int lineCount = 0;  // Contador de l�neas procesadas

    while (getline(file, line)) {
        LogEntry entry;
        stringstream ss(line);
        string token, date;
        int i = 0;

        while (getline(ss, token, ' ')) {
            if (i < 3) {
                date += token + " "; // Primeros tres tokens son la fecha
            }
            else if (i == 3) {
                entry.ipAddress = octToInt(token); // Convierte la IP a formato entero
            }
            else {
                entry.log += token + " "; // El resto es el log
            }
            i++;
        }

        if (!date.empty()) date.pop_back();  // Eliminar espacio final de la fecha
        if (!entry.log.empty()) entry.log.pop_back();  // Eliminar espacio final del log

        logList.insertAtEnd(logList.head, logList.tail, entry);  // Agrega la entrada a la lista
        lineCount++;
    }

    cout << "Successfully read " << lineCount << " lines from the file." << endl;
    file.close();
}

/*
 * Funci�n: linkedListToVector
 * Descripci�n: Convierte la lista doblemente enlazada en un vector para realizar b�squedas
 *              m�s eficientes mediante b�squeda binaria.
 * Par�metros:
 *     - logList: Referencia a la lista enlazada que ser� convertida a vector.
 * Valor de retorno: Un vector que contiene los registros de la bit�cora.
 */
vector<LogEntry> linkedListToVector(LinkedList& logList) {
    vector<LogEntry> logEntries;
    Node* current = logList.head;

    while (current != nullptr) {
        logEntries.push_back(current->data);
        current = current->next;
    }

    cout << "Converted linked list to vector with " << logEntries.size() << " entries." << endl;
    return logEntries;
}

/*
 * Funci�n: intToOct
 * Descripci�n: Convierte una direcci�n IP en formato entero de 32 bits a su formato string
 *              en notaci�n decimal punteada.
 * Par�metros:
 *     - ip: Direcci�n IP en formato entero de 32 bits.
 * Valor de retorno: La direcci�n IP en formato string.
 */
string intToOct(uint32_t ip) {
    return to_string((ip >> 24) & 0xFF) + "." +
        to_string((ip >> 16) & 0xFF) + "." +
        to_string((ip >> 8) & 0xFF) + "." +
        to_string(ip & 0xFF);
}

int main() {
    LinkedList logList;

    // Leer los registros de la bit�cora
    readTxt(logList);

    // Ordenar la lista enlazada por direcciones IP usando quickSort
    logList.sort();
    cout << "Sorted the linked list by IP addresses." << endl;

    // Convertir la lista ordenada a un vector para realizar b�squeda binaria
    vector<LogEntry> logEntries = linkedListToVector(logList);

    // Solicitar al usuario el rango de direcciones IP
    string startIp, endIp;
    cout << "Enter start IP: ";
    cin >> startIp;
    cout << "Enter end IP: ";
    cin >> endIp;

    // Convertir las IPs a formato entero y almacenarlas en octQuery
    octQuery query;
    query.startIP = octToInt(startIp);
    query.endIP = octToInt(endIp);

    // Verificar si el rango est� invertido y corregir si es necesario
    if (query.startIP > query.endIP) {
        swap(query.startIP, query.endIP);
        cout << "Swapped IP range to: " << intToOct(query.startIP) << " - " << intToOct(query.endIP) << endl;
    }

    // Abrir un archivo para escribir los resultados
    ofstream outFile("result_logs.txt");
    if (!outFile.is_open()) {
        cerr << "Unable to open result_logs.txt for writing" << endl;
        return 1;
    }

    outFile << "Writing logs within range: " << intToOct(query.startIP) << " - " << intToOct(query.endIP) << "\n";

    // Realizar b�squeda binaria para encontrar el punto de inicio del rango
    int resultIndex = binaryQuery(logEntries, 0, logEntries.size() - 1, query.startIP);
    cout << "Binary search returned index: " << resultIndex << endl;

    if (resultIndex != -1) {
        // Recorrer las entradas para encontrar los registros dentro del rango de IPs
        cout << "Logs found in the range: \n";
        outFile << "Logs found in the range: \n";
        for (int i = resultIndex; i < logEntries.size(); i++) {
            if (logEntries[i].ipAddress >= query.startIP && logEntries[i].ipAddress <= query.endIP) {
                string ipStr = intToOct(logEntries[i].ipAddress);

                cout << "IP: " << ipStr << " | Log: " << logEntries[i].log << endl;
                outFile << "IP: " << ipStr << " | Log: " << logEntries[i].log << endl;
            }
            else if (logEntries[i].ipAddress > query.endIP) {
                break; // No es necesario continuar si la IP est� fuera del rango
            }
        }
    }
    else {
        cout << "No logs found in the given IP range: " << startIp << " - " << endIp << endl;
        outFile << "No logs found in the given IP range: " << startIp << " - " << endIp << endl;
    }

    // Cerrar el archivo de salida
    outFile.close();
    cout << "Results written to result_logs.txt" << endl;

    return 0;
}
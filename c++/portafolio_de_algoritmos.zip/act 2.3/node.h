 #pragma once

#include <string>
#include <vector>
#include <stdint.h>

// Estructura LogEntry para representar una entrada de bit�cora con IP y log
struct LogEntry {
    uint32_t ipAddress;
    std::string log;
};

// Estructura octQuery para almacenar el rango de IPs de b�squeda
struct octQuery {
    uint32_t startIP;
    uint32_t endIP;
};

// Clase Node para representar un nodo en la lista enlazada
class Node {
public:
    LogEntry data;
    Node* next;
    Node* prev;

    Node();               // Constructor por defecto
    Node(LogEntry data);  // Constructor con par�metros
};

// Clase LinkedList para implementar la lista doblemente enlazada
class LinkedList {
public:
    Node* head;
    Node* tail;

    LinkedList();  // Constructor

    void insertAtBeginning(Node*& head, Node*& tail, LogEntry data);
    void insertAtEnd(Node*& head, Node*& tail, LogEntry data);
    void displayForward();  // Mostrar la lista desde el inicio hasta el final
    void quickSort(Node* start, Node* end);  // Funci�n Quicksort
    Node* partition(Node* low, Node* high);  // Funci�n de partici�n
    void sort();  // Iniciar el proceso de ordenamiento
};

// Funciones auxiliares
uint32_t octToInt(std::string oct);  // Convertir IP en formato string a entero
int compareOctToInt(uint32_t ip1, uint32_t ip2);  // Comparar dos IPs en formato entero
int binaryQuery(std::vector<LogEntry>& arr, int izquierda, int derecha, uint32_t targetIP);  // B�squeda binaria